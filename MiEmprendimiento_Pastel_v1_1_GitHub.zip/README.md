# Mi Emprendimiento — versión pastel

Proyecto Android de prueba basado en el plano visual aprobado: navegación inferior, menú lateral, tarjetas pastel, modo oscuro y módulos de gestión.

Para GitHub: sube este ZIP a la raíz del repositorio y usa el workflow `build-apk.yml` que ya está incluido si decides extraer el proyecto directamente.
