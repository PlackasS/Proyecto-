
package com.emprendimiento.admin;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int BG, SURFACE, CARD, TEXT, TEAL;
    boolean dark=false;
    LinearLayout root, body;
    SharedPreferences prefs;
    String page="Inicio";
    ArrayList<String> materials=new ArrayList<>(), tools=new ArrayList<>(), products=new ArrayList<>(), moves=new ArrayList<>(), notes=new ArrayList<>();

    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("data",0);dark=prefs.getBoolean("dark",false);load();render(page);}
    void colors(){
        if(dark){BG=Color.rgb(15,32,40);SURFACE=Color.rgb(24,49,59);CARD=Color.rgb(32,68,81);TEXT=Color.rgb(238,248,247);TEAL=Color.rgb(54,198,176);}
        else{BG=Color.rgb(255,249,241);SURFACE=Color.WHITE;CARD=Color.WHITE;TEXT=Color.rgb(32,54,64);TEAL=Color.rgb(39,169,149);}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }
    TextView text(String s,float sz){TextView t=new TextView(this);t.setText(s);t.setTextSize(sz);t.setTextColor(TEXT);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(12),dp(5),dp(12),dp(5));return t;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),dark?Color.rgb(54,86,96):Color.rgb(224,235,232));return g;}
    Button action(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(bg(TEAL,18));b.setPadding(dp(10),0,dp(10),0);return b;}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(dark?Color.LTGRAY:Color.GRAY);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(bg(SURFACE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    void render(String p){
        page=p; colors();
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setClipToPadding(false);
        ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets)->{
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(v.getPaddingLeft(),bars.top,v.getPaddingRight(),bars.bottom);
            return insets;
        });
        root.addView(header(),new LinearLayout.LayoutParams(-1,dp(66)));
        ScrollView sv=new ScrollView(this);
        sv.setClipToPadding(false);
        body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14),dp(4),dp(14),dp(22));
        sv.addView(body);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(bottom(),new LinearLayout.LayoutParams(-1,dp(68)));
        setContentView(root);
        ViewCompat.requestApplyInsets(root);
        draw(p);
    }
    View header(){
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(8),dp(4),dp(8),dp(4));
        Button menu=action("☰");menu.setTextColor(TEXT);menu.setBackground(bg(dark?CARD:Color.WHITE,18));menu.setOnClickListener(v->drawer());
        h.addView(menu,new LinearLayout.LayoutParams(dp(52),dp(50)));
        LinearLayout title=new LinearLayout(this);title.setOrientation(LinearLayout.VERTICAL);TextView a=text("🌿  Mi Emprendimiento",16);a.setTypeface(null,1);title.addView(a);title.addView(text("Tu caja, en orden",12));h.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button bell=action("♧");bell.setTextColor(TEXT);bell.setBackground(bg(dark?CARD:Color.WHITE,18));bell.setOnClickListener(v->toast("No hay alertas nuevas"));h.addView(bell,new LinearLayout.LayoutParams(dp(50),dp(50)));return h;
    }
    View bottom(){
        LinearLayout n=new LinearLayout(this);n.setGravity(Gravity.CENTER);n.setPadding(4,4,4,4);n.setBackground(bg(dark?Color.rgb(18,40,49):Color.WHITE,0));
        String[] labels={"⌂\nInicio","▣\nNotas","⚒\nHerramientas","◇\nMateriales","•••\nMás"};
        String[] pages={"Inicio","Notas y agendas","Herramientas y accesorios","Materiales y stock","Más"};
        for(int i=0;i<labels.length;i++){final String pg=pages[i];Button b=action(labels[i]);b.setTextColor(pg.equals(page)?TEAL:TEXT);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->{if(pg.equals("Más"))drawer();else render(pg);});n.addView(b,new LinearLayout.LayoutParams(0,-1,1));}return n;
    }
    void title(String h,String sub){TextView a=text(h,24);a.setTypeface(null,1);a.setPadding(dp(6),dp(10),dp(6),0);body.addView(a);if(sub!=null){TextView b=text(sub,14);b.setPadding(dp(6),0,dp(6),dp(10));body.addView(b);}}
    void card(String title,String value,String detail,int color){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(9),dp(14),dp(9));c.setBackground(bg(dark?CARD:color,18));c.addView(text(title,12));TextView v=text(value,19);v.setTypeface(null,1);c.addView(v);if(detail!=null)c.addView(text(detail,11));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(88));p.setMargins(0,dp(5),0,dp(5));body.addView(c,p);}
    void section(String s){TextView t=text(s,18);t.setTypeface(null,1);t.setPadding(dp(6),dp(14),dp(6),dp(6));body.addView(t);}
    void draw(String p){
        if(p.equals("Inicio"))home();
        else if(p.equals("Mi emprendimiento"))profile();
        else if(p.equals("Notas y agendas"))notes();
        else if(p.equals("Herramientas y accesorios"))tools();
        else if(p.equals("Materiales y stock"))materials();
        else if(p.equals("Calculadora de precios"))calculator();
        else if(p.equals("Movimientos"))movements();
        else if(p.equals("Stock y ventas"))stock();
        else manual();
    }
    void home(){
        title("🏪  Mi Emprendimiento","Tu caja, en orden");
        TextView date=text("▣   Hoy, "+new java.text.SimpleDateFormat("d 'de' MMMM 'de' yyyy",new java.util.Locale("es","CL")).format(new java.util.Date()),13);body.addView(date);
        card("💼  Saldo en caja","$ 125.800","Disponible",Color.rgb(221,244,234));
        LinearLayout row=new LinearLayout(this);body.addView(row);
        mini(row,"↑  Ingresos hoy","$ 68.500","3 movimientos",Color.rgb(221,244,234));
        mini(row,"↓  Gastos hoy","$ 24.300","2 movimientos",Color.rgb(255,232,232));
        section("Resumen del mes");
        LinearLayout r=new LinearLayout(this);body.addView(r);mini(r,"Ingresos","$ 420.500",null,Color.rgb(221,244,234));mini(r,"Gastos","$ 260.400",null,Color.rgb(255,232,232));mini(r,"Total","$ 160.100",null,Color.rgb(221,238,250));
        card("📦  Stock y materiales","18 productos en stock","⚠  2 con bajo stock",Color.rgb(255,232,210));
        section("Accesos rápidos");
        String[][] q={{"🏪","Mi emprendimiento","Mi emprendimiento"},{"▣","Notas y agendas","Notas y agendas"},{"⚒","Herramientas y accesorios","Herramientas y accesorios"},{"◇","Materiales y stock","Materiales y stock"},{"▦","Calculadora de precios","Calculadora de precios"},{"⇄","Movimientos","Movimientos"},{"🛒","Stock y ventas","Stock y ventas"},{"▤","Manual de uso","Manual de uso"}};
        for(String[] x:q){Button b=action(x[0]+"  "+x[1]);b.setTextColor(TEXT);b.setBackground(bg(dark?CARD:Color.WHITE,16));b.setOnClickListener(v->render(x[2]));body.addView(b,new LinearLayout.LayoutParams(-1,dp(48)));}}
    void mini(LinearLayout row,String a,String b,String c,int col){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(10),dp(7),dp(10),dp(7));x.setBackground(bg(dark?CARD:col,16));x.addView(text(a,12));TextView v=text(b,17);v.setTypeface(null,1);x.addView(v);if(c!=null)x.addView(text(c,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(78),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));row.addView(x,p);}
    void profile(){title("Mi emprendimiento","Información general");card("🏪  Tu negocio",prefs.getString("biz","Mi Emprendimiento"),"Producción y venta de productos",Color.rgb(221,244,234));fieldAdd("Nombre del emprendimiento",prefs.getString("biz","Mi Emprendimiento"));Button s=action("Guardar información");body.addView(s);s.setOnClickListener(v->toast("Información guardada"));section("Preferencias");Switch sw=new Switch(this);sw.setText("Modo oscuro");sw.setTextColor(TEXT);sw.setChecked(dark);sw.setOnCheckedChangeListener((b,c)->{dark=c;prefs.edit().putBoolean("dark",c).apply();render("Mi emprendimiento");});body.addView(sw);section("Cuenta");body.addView(text("Usuario: "+prefs.getString("user","usuario"),14));Button out=action("Cerrar sesión");body.addView(out);out.setOnClickListener(v->login());}
    void fieldAdd(String hint,String val){EditText e=field(hint);e.setText(val);body.addView(e);}
    void notes(){title("Notas y Agendas","Calendario, agenda y recordatorios");LinearLayout tabs=new LinearLayout(this);for(String s:new String[]{"Calendario","Agenda","Notas"}){Button b=action(s);b.setTextColor(TEXT);tabs.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));}body.addView(tabs);card("‹       Abril 2025       ›","L  M  M  J  V  S  D","  1   2   3   4   5   6\n  7   8   9  10  11  12  13\n 14  15  16  17  18  19  20",Color.rgb(221,238,250));section("Próximos eventos");for(String n:notes)body.addView(text("●  "+n,14));Button b=action("+ Nueva nota");body.addView(b);b.setOnClickListener(v->newNote());}
    void newNote(){EditText e=field("Título de la nota");body.addView(e);Button b=action("Guardar nota");body.addView(b);b.setOnClickListener(v->{notes.add(e.getText().toString());persist();render("Notas y agendas");});}
    void tools(){title("Herramientas y Accesorios","Costo de desgaste por uso");Button a=action("+  Agregar herramienta");body.addView(a);a.setOnClickListener(v->addTool());for(String x:tools)card("🛠  "+x,"", "Editar     Eliminar",Color.rgb(221,244,234));}
    void addTool(){EditText n=field("Nombre"),v=field("Valor"),u=field("Usos estimados");body.addView(n);body.addView(v);body.addView(u);Button b=action("Guardar herramienta");body.addView(b);b.setOnClickListener(x->{tools.add(n.getText()+" | $ "+v.getText()+" | "+u.getText()+" usos");persist();render("Herramientas y accesorios");});}
    void materials(){title("Materiales y Stock","Control de insumos disponibles");Button a=action("+  Nuevo material");body.addView(a);a.setOnClickListener(v->addMaterial());for(String x:materials)card("📦  "+x,"","Editar     Eliminar",Color.rgb(255,232,210));}
    void addMaterial(){EditText n=field("Nombre"),s=field("Stock"),v=field("Valor por unidad");body.addView(n);body.addView(s);body.addView(v);Button b=action("Guardar material");body.addView(b);b.setOnClickListener(x->{materials.add(n.getText()+" | Stock: "+s.getText()+" | $ "+v.getText()+" c/u");persist();render("Materiales y stock");});}
    void calculator(){title("Calculadora de precios","Calculá el costo completo del producto");fieldAdd("Producto","");section("Materiales");for(String x:materials)body.addView(text("• "+x,13));fieldAdd("Subtotal materiales","0");fieldAdd("Mano de obra","0");section("Herramientas");for(String x:tools)body.addView(text("• "+x,13));fieldAdd("Subtotal herramientas","0");card("Precio final","$ 12.250","Materiales + mano de obra + herramientas",Color.rgb(221,238,250));Button b=action("Calcular y guardar producto");body.addView(b);b.setOnClickListener(v->toast("Producto guardado")); }
    void movements(){title("Movimientos","Ingresos, gastos y transferencias");Button b=action("+  Nuevo movimiento");body.addView(b);b.setOnClickListener(v->addMove());for(String x:moves)body.addView(text("●  "+x,14));}
    void addMove(){EditText d=field("Descripción"),a=field("Monto");body.addView(d);body.addView(a);Button b=action("Guardar movimiento");body.addView(b);b.setOnClickListener(v->{moves.add(d.getText()+"  •  $ "+a.getText());persist();render("Movimientos");});}
    void stock(){title("Stock y ventas","Productos disponibles y vendidos");card("Unidades vendidas","12","Total recaudado  $ 180.000",Color.rgb(221,238,250));section("Productos más vendidos");for(String x:products)body.addView(text("🛒  "+x,14));Button b=action("Ver informe completo");body.addView(b);}
    void manual(){title("Manual de uso","Guía rápida");String[] a={"Entrá a tu cuenta","Conocé el menú","Poné tu emprendimiento","Usá Notas, Agenda y Calendario","Cargá tus herramientas y materiales","Armá un producto y su precio","Registrá un ingreso o gasto","Revisá el stock y las ventas","Activá el modo oscuro"};for(String x:a)body.addView(text("›  "+x,14));}
    void drawer(){PopupWindow pw=new PopupWindow(this);LinearLayout d=new LinearLayout(this);d.setOrientation(LinearLayout.VERTICAL);d.setPadding(dp(14),dp(18),dp(14),dp(14));d.setBackgroundColor(dark?SURFACE:Color.WHITE);TextView h=text("🌿  Mi Emprendimiento",18);h.setTypeface(null,1);d.addView(h);String[] ps={"Inicio","Mi emprendimiento","Notas y agendas","Herramientas y accesorios","Materiales y stock","Calculadora de precios","Movimientos","Stock y ventas","Manual de uso"};for(String x:ps){Button b=action(x);b.setTextColor(TEXT);b.setBackground(bg(dark?CARD:Color.WHITE,14));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->{pw.dismiss();render(x);});d.addView(b,new LinearLayout.LayoutParams(dp(310),dp(46)));}Switch sw=new Switch(this);sw.setText("Modo oscuro");sw.setTextColor(TEXT);sw.setChecked(dark);sw.setOnCheckedChangeListener((bb,c)->{dark=c;prefs.edit().putBoolean("dark",c).apply();pw.dismiss();render(page);});d.addView(sw);Button out=action("Cerrar sesión");d.addView(out);out.setOnClickListener(v->{pw.dismiss();login();});pw.setContentView(d);pw.setWidth(dp(330));pw.setHeight(-1);pw.setBackgroundDrawable(bg(dark?SURFACE:Color.WHITE,0));pw.setOutsideTouchable(true);pw.setFocusable(true);pw.showAtLocation(root,Gravity.LEFT|Gravity.TOP,0,dp(24));}
    void login(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER_HORIZONTAL);l.setPadding(dp(22),dp(70),dp(22),dp(20));l.setBackgroundColor(BG);TextView logo=text("🌿",52);logo.setGravity(Gravity.CENTER);l.addView(logo);TextView h=text("Mi Emprendimiento",26);h.setGravity(Gravity.CENTER);h.setTypeface(null,1);l.addView(h);TextView s=text("Tu caja, en orden",15);s.setGravity(Gravity.CENTER);l.addView(s);EditText u=field("Usuario"),p=field("Contraseña");p.setInputType(129);l.addView(u);l.addView(p);Button b=action("Iniciar sesión");l.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));b.setOnClickListener(v->render("Inicio"));Button r=action("Crear cuenta");r.setTextColor(TEXT);r.setBackground(bg(SURFACE,18));l.addView(r,new LinearLayout.LayoutParams(-1,dp(54)));r.setOnClickListener(v->toast("Registro preparado para la siguiente versión"));setContentView(l);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void persist(){prefs.edit().putString("materials",join(materials)).putString("tools",join(tools)).putString("products",join(products)).putString("moves",join(moves)).putString("notes",join(notes)).apply();}
    String join(ArrayList<String> a){return android.text.TextUtils.join("§",a);}
    void load(){split(prefs.getString("materials",""),materials);split(prefs.getString("tools",""),tools);split(prefs.getString("products",""),products);split(prefs.getString("moves",""),moves);split(prefs.getString("notes",""),notes);}
    void split(String s,ArrayList<String> a){if(s!=null&&!s.isEmpty())a.addAll(Arrays.asList(s.split("§",-1)));}
}
