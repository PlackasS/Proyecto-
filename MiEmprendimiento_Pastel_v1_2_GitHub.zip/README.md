# Mi Emprendimiento – versión 1.2.0

Aplicación Android de gestión para un pequeño emprendimiento. Esta versión mantiene el diseño pastel suave y agrega modo oscuro, navegación por módulos y márgenes seguros para respetar la barra de estado y la navegación del teléfono.

## Módulos
- Inicio / resumen
- Mi emprendimiento
- Notas y agendas
- Herramientas y accesorios
- Materiales y stock
- Calculadora de precios
- Movimientos
- Stock y ventas
- Manual de uso

El proyecto está preparado para compilarse mediante GitHub Actions usando el workflow incluido en `.github/workflows/build-apk.yml`.
