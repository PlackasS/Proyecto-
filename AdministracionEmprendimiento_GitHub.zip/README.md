# Administración Emprendimiento
Primera reconstrucción funcional Android basada en el plano visual: tonos pastel suaves + modo oscuro, login/registro local, inicio/caja, emprendimiento, notas/agendas, herramientas, materiales, calculadora, movimientos, stock/ventas y manual.

## GitHub → APK
1. Sube el contenido de este ZIP al repositorio (no subas el ZIP dentro del repositorio).
2. Ve a **Actions**.
3. Abre **Construir APK** y pulsa **Run workflow**.
4. Cuando termine, abre la ejecución y descarga **AdministracionEmprendimiento-debug**.

Esta versión es la base funcional para probar y corregir pantalla por pantalla. Luego refinaremos diseño, relaciones de datos y funciones según la referencia original.
